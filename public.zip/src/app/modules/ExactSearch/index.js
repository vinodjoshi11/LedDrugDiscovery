import { useState } from "react";
const ExactSearch = () => {
    
    return (<>
        <div className="exactSearchContent">
            <img src={"/images/diagram.png"} alt={"diagram"} />
        </div>
        <div className="imageNo">
            DRL_9584767
        </div>
    </>)
}
export default ExactSearch;