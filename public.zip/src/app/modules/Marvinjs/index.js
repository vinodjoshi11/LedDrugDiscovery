const Marvinjs=()=>{ 
    return(<>
  <iframe width="100%" height={`550`} src="/marvinjs-23.8.0-all/demo.html" title="W3Schools Free Online Web Tutorials"></iframe>
    </>)
}
export default Marvinjs;