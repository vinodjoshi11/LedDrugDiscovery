import { useState } from "react";
const dataList = [{
    title: "Target", result: [{ label: "heRG", checked: true },
    { label: "cav1.2", checked: true }, { label: "nav1.5", checked: true }]
},
{
    title: "Value Type", result: [{ label: "heRG", checked: true },
    { label: "cav1.2", checked: true }, { label: "nav1.5", checked: true }]
},
{
    title: "Assay Type", result: [{ label: "heRG", checked: true },
    { label: "cav1.2", checked: true }, { label: "nav1.5", checked: true }]
}]
const StructureSearch = () => {
    const [data, setData] = useState(dataList)
    const onChange = (index, k, isChecked) => {
        const filterData = dataList.filter((item, i) => {
            if (i === index) {
                item.result.filter((r, j) => {
                    if (j === k) {
                        r.checked = !isChecked;
                    }
                    return r;
                })
            }
            return item;
        });
        setData(filterData);
    }
    return (<>
        <div className="similarySearchContent">
            <div className="bigImage">
                <img src={"/images/diagram.png"} alt={"diagram"} />
                <div className="imageNo">
                    DRL_9584767
                </div>
            </div>
            <div className="thumbnail">
                <ul>
                    <li className="active"><img src={"/images/diagram.png"} alt={"diagram"} /></li>
                    <li><img src={"/images/diagram.png"} alt={"diagram"} /></li>
                    <li><img src={"/images/diagram.png"} alt={"diagram"} /></li>
                </ul>
            </div>
        </div>
        {/* <AccordionList onChange={onChange} accordions={data} /> */}
    </>)
}
export default StructureSearch;